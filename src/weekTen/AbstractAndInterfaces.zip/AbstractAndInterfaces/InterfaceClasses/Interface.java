package weekTen.AbstractAndInterfaces.InterfaceClasses;

public interface Interface {
    int numberOfLikes();
}
